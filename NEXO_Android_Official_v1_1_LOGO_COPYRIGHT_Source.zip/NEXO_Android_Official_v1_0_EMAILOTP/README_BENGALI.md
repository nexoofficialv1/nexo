# NEXO Official Android APK v1.0 — Email OTP Compatible

এই Android source GitHub Actions দিয়ে APK build করার জন্য প্রস্তুত।

## Final Settings

- App Name: NEXO
- Default Backend URL: https://nexoofficial.in
- Backend Setup Screen: Hidden by default; only connection error হলে settings পাওয়া যাবে
- HTTPS only
- File picker / attachment upload supported
- Email OTP backend compatible
- Launcher Logo: NEXO official logo added
- Copyright: Copyright © 2026 ASTRA Technologies

## Build

GitHub repo-তে ZIP extract/upload করুন, তারপর:

Actions → Build NEXO Official APK → Run workflow

Build complete হলে artifact থেকে `app-debug.apk` download করে install করুন।

## Test URLs

- https://nexoofficial.in/api/health
- https://nexoofficial.in/mobile/
- https://nexoofficial.in/admin/

## APK Test Flow

1. App install
2. App open করলে direct NEXO login page আসবে
3. User ID / password দিয়ে login
4. Email OTP receive
5. OTP verify
6. Dashboard open

## Note

এটি debug APK/pilot APK. Public release-এর আগে signed release APK বানাতে হবে।
