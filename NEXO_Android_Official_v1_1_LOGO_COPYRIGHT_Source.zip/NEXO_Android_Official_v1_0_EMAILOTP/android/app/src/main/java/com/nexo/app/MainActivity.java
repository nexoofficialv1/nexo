package com.nexo.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.http.SslError;
import android.webkit.JavascriptInterface;
import android.webkit.SslErrorHandler;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;
    private SharedPreferences prefs;
    private ValueCallback<Uri[]> filePathCallback;

    private static final String PREFS = "nexo_prefs";
    private static final String KEY_SERVER_URL = "server_url";
    private static final String DEFAULT_BASE_URL = "https://nexoofficial.in";
    private static final int FILE_CHOOSER_REQUEST = 5010;

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);

        webView = new WebView(this);
        setContentView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        }

        webView.addJavascriptInterface(new Bridge(), "NexoAndroid");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                try {
                    Intent intent = params.createIntent();
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                } catch (Exception e) {
                    Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("*/*");
                    startActivityForResult(Intent.createChooser(intent, "Select file for NEXO"), FILE_CHOOSER_REQUEST);
                }
                return true;
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (request != null && request.getUrl() != null) {
                    String u = request.getUrl().toString();
                    if (u.startsWith("tel:") || u.startsWith("mailto:") || u.startsWith("whatsapp:")) {
                        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u))); } catch (Exception ignored) {}
                        return true;
                    }
                }
                return false;
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request != null && request.isForMainFrame()) {
                    String desc = "Connection error";
                    if (error != null && android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                        desc = error.getDescription().toString();
                    }
                    showErrorPage(getMobileUrl(), desc);
                }
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                handler.cancel();
                showErrorPage(getMobileUrl(), "SSL certificate error. Please check https://nexoofficial.in certificate.");
            }
        });

        showSplashPage();
        webView.postDelayed(() -> loadNexo(), 900);
    }


    private void showSplashPage() {
        String html = "<!doctype html><html><head><meta name='viewport' content='width=device-width, initial-scale=1'>"+
                "<style>*{box-sizing:border-box}body{margin:0;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial;background:linear-gradient(180deg,#061d36,#0b4384);min-height:100vh;color:#fff;display:flex;align-items:center;justify-content:center;text-align:center}.wrap{padding:26px}.mark{width:104px;height:104px;border-radius:30px;background:#fff;color:#0b4384;font-size:58px;font-weight:900;display:flex;align-items:center;justify-content:center;margin:0 auto 22px;box-shadow:0 22px 55px rgba(0,0,0,.28)}h1{font-size:42px;letter-spacing:8px;margin:0 0 8px}p{margin:0;color:#c7dcf5;font-size:15px}.copy{position:fixed;left:0;right:0;bottom:28px;color:#b9d0ec;font-size:13px}</style></head><body>"+
                "<div class='wrap'><div class='mark'>N</div><h1>NEXO</h1><p>Official Messaging with Accountability</p></div>"+
                "<div class='copy'>Copyright © 2026 ASTRA Technologies</div>"+
                "</body></html>";
        webView.loadDataWithBaseURL("https://nexo.local/splash/", html, "text/html", "UTF-8", null);
    }

    private String getBaseUrl() {
        String saved = prefs.getString(KEY_SERVER_URL, DEFAULT_BASE_URL);
        if (saved == null || saved.trim().isEmpty()) saved = DEFAULT_BASE_URL;
        return normalizeBase(saved);
    }

    private String getMobileUrl() {
        String base = getBaseUrl();
        if (base.endsWith("/")) return base + "mobile/";
        return base + "/mobile/";
    }

    private String normalizeBase(String url) {
        if (url == null) return DEFAULT_BASE_URL;
        url = url.trim();
        if (url.length() == 0) return DEFAULT_BASE_URL;
        if (!url.startsWith("https://")) {
            if (url.startsWith("http://")) url = "https://" + url.substring(7);
            else url = "https://" + url;
        }
        if (url.endsWith("/mobile/")) url = url.substring(0, url.length() - 8);
        else if (url.endsWith("/mobile")) url = url.substring(0, url.length() - 7);
        while (url.endsWith("/")) url = url.substring(0, url.length() - 1);
        return url;
    }

    private void loadNexo() {
        if (!hasNetwork()) {
            showErrorPage(getMobileUrl(), "No internet connection");
            return;
        }
        webView.loadUrl(getMobileUrl());
    }

    private boolean hasNetwork() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo info = cm == null ? null : cm.getActiveNetworkInfo();
            return info != null && info.isConnected();
        } catch (Exception e) {
            return true;
        }
    }

    private void saveAndOpen(String url) {
        final String finalBase = normalizeBase(url);
        prefs.edit().putString(KEY_SERVER_URL, finalBase).apply();
        runOnUiThread(this::loadNexo);
    }

    private void resetToOfficial() {
        prefs.edit().putString(KEY_SERVER_URL, DEFAULT_BASE_URL).apply();
        runOnUiThread(this::loadNexo);
    }

    private void showSetupPage() {
        String current = getBaseUrl();
        String html = "<!doctype html><html><head><meta name='viewport' content='width=device-width, initial-scale=1'>"+
                "<style>*{box-sizing:border-box}body{margin:0;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial;background:linear-gradient(180deg,#061d36,#0b4384);min-height:100vh;color:#172033;padding:34px 22px}.logo{width:86px;height:86px;border-radius:24px;background:#1767ff;color:#fff;font-size:44px;font-weight:900;display:flex;align-items:center;justify-content:center;margin:10px 0 18px}.brand{color:#fff}.brand h1{margin:0;font-size:34px}.brand p{margin:8px 0 42px;color:#bfd3ee;font-size:18px}.card{background:#fff;border-radius:28px;padding:24px;box-shadow:0 22px 60px rgba(0,0,0,.22)}label{font-weight:800;color:#6b7481;font-size:14px}.inp{width:100%;padding:17px 16px;border:1px solid #d9e1ee;border-radius:16px;margin:9px 0 15px;font-size:16px}.btn{width:100%;border:0;border-radius:16px;background:#1767ff;color:white;font-size:18px;padding:16px;margin:7px 0;font-weight:800}.btn2{background:#eef5ff;color:#1767ff}.hint{font-size:13px;color:#687482;line-height:1.5}.small{font-size:12px;color:#d8e8ff;margin-top:18px;line-height:1.45}</style></head><body>"+
                "<div class='logo'>N</div><div class='brand'><h1>NEXO</h1><p>Official Messaging with Accountability</p></div>"+
                "<div class='card'><h2 style='margin-top:0'>Server Settings</h2>"+
                "<p class='hint'>Official server already set. Change only if testing another backend.</p>"+
                "<label>Backend URL</label><input class='inp' id='url' value='"+current+"'>"+
                "<button class='btn' onclick='openApp()'>Save & Open NEXO</button>"+
                "<button class='btn btn2' onclick='NexoAndroid.resetToOfficial()'>Use Official Server</button>"+
                "</div><p class='small'>NEXO Official APK v1.0 • Backend: https://nexoofficial.in<br>Copyright © 2026 ASTRA Technologies</p>"+
                "<script>function openApp(){var u=document.getElementById('url').value;if(!u){alert('Backend URL দিন');return;}NexoAndroid.saveAndOpen(u);}</script>"+
                "</body></html>";
        webView.loadDataWithBaseURL("https://nexo.local/setup/", html, "text/html", "UTF-8", null);
    }

    private void showErrorPage(String url, String errorText) {
        String safeUrl = url == null ? "" : url.replace("'", "").replace("<", "&lt;").replace(">", "&gt;");
        String safeError = errorText == null ? "Connection error" : errorText.replace("<", "&lt;").replace(">", "&gt;");
        String html = "<!doctype html><html><head><meta name='viewport' content='width=device-width, initial-scale=1'>"+
                "<style>body{margin:0;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial;background:#071d36;color:#172033;padding:28px 20px}.card{background:#fff;border-radius:26px;padding:24px;margin-top:45px}.title{color:#fff;font-size:32px;font-weight:900}.sub{color:#bdd3ee;margin-top:8px}.err{background:#ffecec;border:1px solid #ffcaca;border-radius:14px;padding:13px;margin:14px 0;color:#8a1010}.url{background:#f5f7fb;border-radius:14px;padding:12px;word-break:break-all;color:#2b3645}.btn{width:100%;border:0;border-radius:16px;background:#1767ff;color:#fff;padding:16px;font-size:17px;font-weight:800;margin-top:12px}.btn2{background:#eef5ff;color:#1767ff}.list{color:#687482;line-height:1.65;font-size:14px}</style></head><body>"+
                "<div class='title'>NEXO</div><div class='sub'>Official connection diagnostic</div><div class='card'>"+
                "<h2 style='margin-top:0'>Connection issue</h2>"+
                "<div class='err'>"+safeError+"</div>"+
                "<div class='url'>Tried URL: "+safeUrl+"</div>"+
                "<div class='list'><ol><li>Internet connection check করুন</li><li>Chrome-এ https://nexoofficial.in/mobile/ খুলছে কি না দেখুন</li><li>SSL active আছে কি না দেখুন</li></ol></div>"+
                "<button class='btn' onclick='location.reload()'>Retry</button>"+
                "<button class='btn btn2' onclick='NexoAndroid.showSettings()'>Server Settings</button>"+
                "<p style='font-size:12px;color:#768193;text-align:center;margin-top:18px'>Copyright © 2026 ASTRA Technologies</p></div></body></html>";
        webView.loadDataWithBaseURL("https://nexo.local/error/", html, "text/html", "UTF-8", null);
    }

    public class Bridge {
        @JavascriptInterface public void saveAndOpen(String url) { MainActivity.this.saveAndOpen(url); }
        @JavascriptInterface public void resetToOfficial() { MainActivity.this.resetToOfficial(); }
        @JavascriptInterface public void showSettings() { runOnUiThread(() -> MainActivity.this.showSetupPage()); }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST) {
            Uri[] results = null;
            if (resultCode == Activity.RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int count = data.getClipData().getItemCount();
                    results = new Uri[count];
                    for (int i = 0; i < count; i++) results[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(results);
                filePathCallback = null;
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
